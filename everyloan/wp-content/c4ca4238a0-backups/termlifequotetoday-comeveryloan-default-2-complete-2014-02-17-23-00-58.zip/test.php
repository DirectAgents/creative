<?php

$test = sprintf('%08d', mt_rand(0,99999999));

echo $test;

?>