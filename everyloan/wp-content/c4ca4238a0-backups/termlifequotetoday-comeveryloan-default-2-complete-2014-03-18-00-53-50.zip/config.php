<?php

$conn = mysql_connect("74.3.216.19", "offsource", "0fF$0uRc3") or die(mysql_error());
$db = mysql_select_db("lifelinescreening") or die(mysql_error());

?>