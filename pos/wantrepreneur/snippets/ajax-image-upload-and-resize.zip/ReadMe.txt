There are two folders. 

1) ajax-image-upload - Simple Ajax Upload and Resize (without resize.class.php).

2) ajax-image-upload-with-class - Multiple Ajax Upload and Resize using "resize.class.php". 

@ Source : 
http://www.sanwebe.com/2012/05/ajax-image-upload-and-resize-with-jquery-and-php

@ PHP : Version 5.2.0 + 
@ jQuery  : v 1.10.2
@ jQuery Form Plugin : v 3.51.0-2014.06.20 (Requires jQuery v1.5 or later)


License : http://opensource.org/licenses/MIT
------------------------------------------------
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.