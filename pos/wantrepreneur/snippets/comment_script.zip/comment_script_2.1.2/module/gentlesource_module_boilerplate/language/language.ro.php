<?php

/** 
 * GentleSource Module Boilerplate
 * 
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 * 
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 * 
 */




$text = array(   

'txt_charset'                       => 'iso-8859-1',



'txt_content'                       => 'Con�inut',

'txt_enable_module'                 => 'Activeaz� Boilerplate',

'txt_enable_module_description'     => 'Aceast� tr�s�tur� afi�eaz� un meniu selectabil care v� permite s� alege�i dintr-o list� de texte reusabile.',

'txt_module_description'            => 'Boilerplate se refer� la orice text care este sau care poate fi reutilizat �n contexte noi (vezi de asemenea <a href="http://en.wikipedia.org/wiki/Boilerplate_%28text%29" target="_blank">Wikipedia</a>).',
'txt_module_name'                   => 'Boilerplate',

'txt_title'                         => 'Titlu',

);








?>
