<?php

/**
 * GentleSource Comment Script - language.en.php
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset'                       => 'iso-8859-1',



'txt_content'                       => 'Inhalt',

'txt_enable_module'                 => 'Textbausteine aktivieren',

'txt_enable_module_description'     => 'Diese Funktion zeigt ein Auswahlmen� mit den von Ihnen definierten Textbausteinen an.',

'txt_module_description'            => 'Erstellen Sie Textbausteine, um wiederkehrenden Text nicht st�ndig neu schreiben zu m�ssen.',
'txt_module_name'                   => 'Textbausteine',

'txt_title'                         => 'Titel',

);








?>
