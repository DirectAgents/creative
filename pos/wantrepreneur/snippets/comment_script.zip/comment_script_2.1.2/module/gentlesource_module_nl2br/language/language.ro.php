<?php

/** 
 * GentleSource Module nl2b4
 * 
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 * 
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 * 
 */




$text = array(   

'txt_charset'                       => 'iso-8859-1',



'txt_enable_module'                 => 'Activeaz� Linii noi',
'txt_enable_module_description'     => 'Activeaz� acest modul pentru a converti liniile noi �n HTML <br />',

'txt_module_description'            => 'Convertire linii noi �n HTML <br />',
'txt_module_name'                   => 'Linii noi',

);








?>
