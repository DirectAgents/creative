<?php

/** 
 * GentleSource Module nl2b4
 * 
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 * 
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 * 
 */




$text = array(   

'txt_charset' => 'utf-8',



'txt_enable_module'                 => 'Activeazã Linii noi',
'txt_enable_module_description'     => 'Activeazã acest modul pentru a converti liniile noi în HTML <br />',

'txt_module_description'            => 'Convertire linii noi în HTML <br />',
'txt_module_name'                   => 'Linii noi',

);








?>
