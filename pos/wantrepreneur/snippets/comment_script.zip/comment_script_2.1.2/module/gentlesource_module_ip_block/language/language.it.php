<?php

/**
 * GentleSource Module IP Block
 * *
 * If you have translated this file into another
 * language or have corrected typos, we would
 * appreciate it if you would send us the
 * translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset'                       => 'iso-8859-1',



'txt_ban_ip'                        => 'Banna IP',

'txt_error_ip_block'                => 'Il tuo indirizzo IP è stato bloccato. Non sei autorizzato ad inserire i commenti.',

'txt_ip_addresses'                  => 'Indirizzo IP',
'txt_ip_addresses_description'      => 'Inserisci un indirizzo IP per linea.',
'txt_ip_block'                      => 'Blocca IP',
'txt_ip_block_description'          => 'Filtra i commenti in base all\'indirizzo IP dell\'utente.',

'txt_moderate'                      => 'Modera',
'txt_module_description'            => 'Filtra/blocca commenti tramite indirizzo IP.',
'txt_module_name'                   => 'Blocca IP',

'txt_notice_moderation'             => 'Il tuo commento sarà pubblicato un volta approvato dai nostri moderatori.',

'txt_off'                           => 'Off',

'txt_reject'                        => 'Respinto',

);








?>
