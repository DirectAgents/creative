<?php

/**
 * GentleSource
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset' => 'utf-8',


'txt_activate_module'               => 'Klickbare URLs/E-Mail aktivieren',
'txt_activate_module_description'   => '',

'txt_module_description'            => 'URLs wie http://www.example.com/ oder www.example.com und E-Mail-Adressen wie example@example.com werden in einen Link umgewandelt und klickbar gemacht.',
'txt_module_name'                   => 'Klickbare URLs',

'txt_parse_email'                   => 'E-Mail-Adressen',
'txt_parse_email_description'       => 'E-Mail-Adressen wie example@example.com in Links umwandeln.',
'txt_parse_url'                     => 'URLs',
'txt_parse_url_description'         => 'URLs wie http://www.example.com/ in Links umwandeln.',
'txt_parse_www'                     => 'WWW',
'txt_parse_www_description'         => 'Www-Adressen wie www.example.com in Links umwandeln.',

);








?>
