<?php

/** 
 * GentleSource Comment Script - language.en.php
 * 
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 * 
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 * 
 */




$text = array(   

'txt_charset'                       => 'iso-8859-1',



'txt_error_content_block'           => 'Comentariul dvs-tr� a fost blocat din cauz� c� este un duplicat.',

'txt_enable_module'                 => 'Protec�ie Repetare',
'txt_enable_module_description'     => 'Pute�i decide dac� comentariul va fi respins sau marcat pentru moderare.',

'txt_moderate'                      => 'Moderare',
'txt_module_description'            => 'Acest modul previne ca utilizatorii s� nu poat� trimite acela�i con�inut(ex. c�nd apas� butonul de Re�nc�rcare a paginii �n mod repetat). Verific� con�inutul �i intr�rile existente �n baza de date.',
'txt_module_name'                   => 'Protec�ie Repetare',

'txt_notice_moderation'             => 'Comentariul dvs-tr� va fi publicat oat� ce va fi aprobat de moderator.',

'txt_off'                           => 'Dezactivare',

'txt_reject'                        => 'Respingere',

);








?>
