<?php

/**
 * GentleSource
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset'                       => 'iso-8859-1',



'txt_error_content_block'           => 'Ihr Kommentar wurde auf Grund von doppentem Inhalt abgeweisen.',

'txt_enable_module'                 => 'Flood Protection',
'txt_enable_module_description'     => 'Sie k�nnen entscheiden, ob der Kommentar moderiert oder blockiert werden soll.',

'txt_moderate'                      => 'Moderieren',
'txt_module_description'            => 'Diese Funktion verhindert, dass Benutzer denselben Kommentar immer wieder abschicken (z.B. durch Neuladen der Seite).',
'txt_module_name'                   => 'Flood Protection',

'txt_notice_moderation'             => 'Ihr Kommentar wird ver�ffentlicht, sobald er vom Betreiber freigegeben wurde.',

'txt_off'                           => 'Aus',

'txt_reject'                        => 'Abweisen',

);








?>
