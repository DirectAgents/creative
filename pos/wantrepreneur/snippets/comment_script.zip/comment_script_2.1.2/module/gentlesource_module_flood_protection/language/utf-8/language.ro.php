<?php

/** 
 * GentleSource Comment Script - language.en.php
 * 
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 * 
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 * 
 */




$text = array(   

'txt_charset' => 'utf-8',



'txt_error_content_block'           => 'Comentariul dvs-trã a fost blocat din cauzã cã este un duplicat.',

'txt_enable_module'                 => 'Protecþie Repetare',
'txt_enable_module_description'     => 'Puteþi decide dacã comentariul va fi respins sau marcat pentru moderare.',

'txt_moderate'                      => 'Moderare',
'txt_module_description'            => 'Acest modul previne ca utilizatorii sã nu poatã trimite acelaºi conþinut(ex. când apasã butonul de Reîncãrcare a paginii în mod repetat). Verificã conþinutul ºi intrãrile existente în baza de date.',
'txt_module_name'                   => 'Protecþie Repetare',

'txt_notice_moderation'             => 'Comentariul dvs-trã va fi publicat oatã ce va fi aprobat de moderator.',

'txt_off'                           => 'Dezactivare',

'txt_reject'                        => 'Respingere',

);








?>
