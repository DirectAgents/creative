<?php

/** 
 * GentleSource Module Akismet
 *
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 * 
 */




$text = array(   

'txt_charset' => 'utf-8',



'txt_akismet_key'                   => 'Cheie Akismet API',
'txt_akismet_key_description'       => 'Puteþi obþine o cheie API gratuitã registrând un cont WordPress.com (http://wordpress.com/signup/). Cheia API va fi trimisã pe e-mailul dvs-trã dupã registrare.',

'txt_error_spam'                    => 'Akismet a marcat comentariul dvs-trã ca spam. De aceea a fost respins.',

'txt_moderate'                      => 'Moderare',
'txt_module_description'            => 'Akismet.com analizeazã comentariile trimise ºi verificã dacã comentariul a fost raportat ca Spam. Trebuie sã obþineþi o cheie API de la adresa http://www.akismet.com prin registrarea unui cont la http://www.wordpress.com/. Daca lasati campul ce contine cheia API, Akismet nu va fi folosit.',
'txt_module_name'                   => 'Akismet',

'txt_notice_moderation'             => 'Comentariile dvs-trã vor fi publicate odatã ce vor fi aprobate de moderator.',

'txt_off'                           => 'Dezactivare',

'txt_reject'                        => 'Respingere',

);








?>
