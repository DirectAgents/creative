<?php

/** 
 * GentleSource Module Akismet
 *
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 * 
 */




$text = array(   

'txt_charset'                       => 'iso-8859-1',



'txt_akismet_key'                   => 'Cheie Akismet API',
'txt_akismet_key_description'       => 'Pute�i ob�ine o cheie API gratuit� registr�nd un cont WordPress.com (http://wordpress.com/signup/). Cheia API va fi trimis� pe e-mailul dvs-tr� dup� registrare.',

'txt_error_spam'                    => 'Akismet a marcat comentariul dvs-tr� ca spam. De aceea a fost respins.',

'txt_moderate'                      => 'Moderare',
'txt_module_description'            => 'Akismet.com analizeaz� comentariile trimise �i verific� dac� comentariul a fost raportat ca Spam. Trebuie s� ob�ine�i o cheie API de la adresa http://www.akismet.com prin registrarea unui cont la http://www.wordpress.com/. Daca lasati campul ce contine cheia API, Akismet nu va fi folosit.',
'txt_module_name'                   => 'Akismet',

'txt_notice_moderation'             => 'Comentariile dvs-tr� vor fi publicate odat� ce vor fi aprobate de moderator.',

'txt_off'                           => 'Dezactivare',

'txt_reject'                        => 'Respingere',

);








?>
