<?php

/** 
 * GentleSource Comment Script - language.en.php
 * 
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 * 
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 * 
 */




$text = array(   

'txt_charset' => 'utf-8',

'txt_enable_module'                 => 'W³±cz logowanie odwo³añ',
'txt_enable_module_description'     => 'Loguj odwo³oania do pliku tekstowego',

'txt_module_description'            => 'Ten modu³ zapisuje dane wchodz±cego na stronê.',
'txt_module_name'                   => 'Logowanie odwo³añ',

'txt_referrer_log'                  => 'Logowanie odwo³añ',
'txt_referrer_log_file'             => 'Otwórz log w nowym oknie',

);








?>
