<?php

/** 
 * GentleSource Comment Script - language.en.php
 * 
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 * 
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 * 
 */




$text = array(   

'txt_charset'                       => 'iso-8859-1',

'txt_enable_module'                 => 'Enable referrer logging',
'txt_enable_module_description'     => 'Log referrer in text file',

'txt_module_description'            => 'The module writes date, time referrer and request URI of a visit to a text file.',
'txt_module_name'                   => 'Referrer Log',

'txt_referrer_log'                  => 'Referrer Log',
'txt_referrer_log_file'             => 'Open referrer log file in a new window',

);








?>
