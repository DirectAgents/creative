<?php

/** 
 * GentleSource Comment Script - language.en.php
 * 
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 * 
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 * 
 */




$text = array(   

'txt_charset'                       => 'iso-8859-1',

'txt_enable_module'                 => 'W��cz logowanie odwo�a�',
'txt_enable_module_description'     => 'Loguj odwo�oania do pliku tekstowego',

'txt_module_description'            => 'Ten modu� zapisuje dane wchodz�cego na stron�.',
'txt_module_name'                   => 'Logowanie odwo�a�',

'txt_referrer_log'                  => 'Logowanie odwo�a�',
'txt_referrer_log_file'             => 'Otw�rz log w nowym oknie',

);








?>
