<?php

/**
 * GentleSource Comment Script - language.it.php
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language or have corrected typos, we would
 * appreciate it if you would send us the
 * translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset' => 'utf-8',



'txt_enable_module'                 => 'Etichetta testo',
'txt_enable_module_description'     => 'Descrizione testo che appare sul modulo delle impostazioni.',

'txt_module_description'            => 'Questo &eacute; un modulo dummy',
'txt_module_name'                   => 'Modulo Dummy',

);








?>
