<?php

/**
 * GentleSource Comment Script - language.en.php
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset'                       => 'iso-8859-1',



'txt_content'                       => 'Inhalt',

'txt_enable_module'                 => 'Inhalte ersetzen',

'txt_enable_module_description'     => 'Ersetzen Sie W�rter durch festgelegte Texte.',

'txt_module_description'            => 'Sie k�nnen diese Funktion nutzen, um W�rter durch anderen Text zu ersetzen. So k�nnen Sie zum Beispiel bestimmte W�rter mit einen Link hinterlegen oder unerw�nschte W�rter durch erw�nschten Text ersetzen.',
'txt_module_name'                   => 'Inhalte ersetzen',

'txt_title'                         => 'Titel',

);








?>
