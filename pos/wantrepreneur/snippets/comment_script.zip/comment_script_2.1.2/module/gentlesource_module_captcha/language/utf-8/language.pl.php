<?php

/**
 * GentleSource
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset' => 'utf-8',



'txt_alternative_captcha'           => 'Uruchom alternatywn± Captchê',
'txt_alternative_captcha_description' => 'W przypadku nie dzia³ania standardowej Captchy, uruchom alternatywn±.',

'txt_captcha_try_again'             => '¬le wpisany kod. Proszê wpisaæ ponownie poprawny kod.',
'txt_captcha_description'           => 'Aby zapobiec spam-botom, proszê spojrzeæ na wygenerowany kod i wpisaæ go w pole tekstowe. Je¿eli kod bêdzie siê zgadza³, wiadomo¶æ zostanie wys³ana.',

'txt_enable_captcha'                => 'W³±cz Captcha',
'txt_enable_captcha_description'    => 'Aby zapobiec spam-botom, mo¿esz wymagaæ od swoich go¶ci na stronie wprowadzenie kodu Captcha przed wys³anie wiadomo¶ci.',

'txt_garbage_collector'             => 'W³±cz zbieranie ¶mieci',
'txt_garbage_collector_description' => 'Wszystkie wygenerowane kody Captcha s± trzymane w folderze tymczasowym. Zbieranie ¶mieci usuwanie je co pewien czas. Je¿eli wy³aczysz t± opcje, twój folder ¶mieci Captcha bêdzie rós³ razem z przybywaj±cymi kodami.',

'txt_font_size'                     => 'Wielko¶æ czcionki',

'txt_image_height'                  => 'Wysoko¶æ obrazka',
'txt_image_width'                   => 'Szerowko¶æ obrazka',

'txt_module_name'                   => 'Obrazek Captcha',
'txt_module_description'            => 'Zapobieganie spam-botom.',

);








?>
