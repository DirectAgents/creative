<?php

/** 
 * GentleSource Module Captcha
 * 
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 * 
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 * 
 */




$text = array(   

'txt_charset'                       => 'iso-8859-1',



'txt_alternative_captcha'           => 'Enable Alternative Captcha',
'txt_alternative_captcha_description' => 'In case the standard Captcha feature does not work enable alternative Captcha.',

'txt_captcha_try_again'             => 'Nu a�i introdus corect textul afi�at �n imaginea de prevenire a Spamului �n c�mpul text. V� rug�m s� v� uita�i la imagine �i s� introduce�i caracterele afi�ate acolo.',
'txt_captcha_description'           => 'Pentru a preveni programele automate de publicitate s� adauge comentarii cu caracter publicitar, v� rug�m s� introduce�i textul pe care �l vede�i �n imaginea de mai jos �n c�mpul text. Comentariul dvs-tr� va fi trimis doar dac� caracterele se potrivesc. V� rug�m s� v� asigura�i c� browser-ul (Internet Explorer, Mozilla Firefox, Opera, Netscape, etc.) suport� �i accept� cookies, ori comentariul dvs-tr� nu poate fi verificat �n mod corespunz�tor.',

'txt_enable_captcha'                => 'Activeaz� Captcha',
'txt_enable_captcha_description'    => 'entru a preveni programele automate de publicitate s� adauge comentarii cu caracter publicitar, pute�i cere vizitatorilor s� recunoasc� textul pe care �l v�d �ntr-o imagine afi�at� mai jos �i s�-l introduc� �ntr-o c�su�� text.Comentariul va fi postat doar dac� cuvintele coincid. Vizitorii trebuie s� se asigure c� browserul lor (Internet Explorer, Mozilla Firefox, Opera, Netscape, etc.) suport� �i accept� cookies, �n mod contrar comentariul neput�nd fi fi verificat �n mod corespunz�tor.',

'txt_garbage_collector'             => 'Activeaz� Colectorul de Gunoi',
'txt_garbage_collector_description' => 'Toate imaghinile CAPTCHA sunt stocate temporar �n directorul cache. Colectorul de Gunoi �terge imaginile captcha vechi dup� o anumit� perioad� de timp. Dac� dezactiva�i aceast� op�iune, directorul cache va fi cur�nd plin de imagin captcha vechi, care nu sunt necesar� �i consum� spa�iul de pe serverul web.',

'txt_font_size'                     => 'M�rimea fontului',

'txt_image_height'                  => '�n�l�imea imaginii',
'txt_image_width'                   => 'L��imea imaginii',

'txt_module_name'                   => 'Imagine Captcha',
'txt_module_description'            => 'Previne programele automate de publicitate s� completeze formularul.',

);








?>
