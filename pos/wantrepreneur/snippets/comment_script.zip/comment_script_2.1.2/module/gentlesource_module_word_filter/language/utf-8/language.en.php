<?php

/**
 * GentleSource Comment Script - language.en.php
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset' => 'utf-8',



'txt_word_list'                     => 'Word List',
'txt_word_list_description'         => 'Enter one word or phrase per line.',

'txt_module_description'            => 'The word filter replaces undesirable words and phrases with a character you can specify below. Enable word filter?',
'txt_module_name'                   => 'Word Filter',

'txt_replacement_character'         => 'Replacement Character(s)',

);








?>
