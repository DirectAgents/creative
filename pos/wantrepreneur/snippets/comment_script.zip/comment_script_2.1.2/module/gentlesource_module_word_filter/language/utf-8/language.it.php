<?php

/**
/**
 * GentleSource Comment Script - language.it.php
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language or have corrected typos, we would
 * appreciate it if you would send us the
 * translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset' => 'utf-8',



'txt_word_list'                     => 'Lista parole',
'txt_word_list_description'         => 'Inserisci una parola o frase per riga.',

'txt_module_description'            => 'Censura Parole sostituisce le parole non desiderate con altre che decidi tu qui di seguito. Vuoi attivare il Censura Parole?',
'txt_module_name'                   => 'Censura Parole',

'txt_replacement_character'         => 'Carattere(i) di rimpiazzo',

);








?>
