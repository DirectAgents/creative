<?php

/** 
 * GentleSource Module Word Filter
 * 
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 * 
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 * 
 */




$text = array(   

'txt_charset' => 'utf-8',



'txt_word_list'                     => 'Listã Cuvinte',
'txt_word_list_description'         => 'Introduceþi un cuvânt sau o frazã pe linie.',

'txt_module_description'            => 'Filtrul de cuvinte înlocuieºte cuvintele nedorite ºi frazele cu un caracter pe care îl puteþi specifica mai în jos. Activaþi Filtrul de cuvinte?',
'txt_module_name'                   => 'Filtru de cuvinte',

'txt_replacement_character'         => 'Caractere pentru înlocuire',

);








?>
