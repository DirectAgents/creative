<?php

/** 
 * GentleSource Module Word Filter
 * 
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 * 
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 * 
 */




$text = array(   

'txt_charset'                       => 'iso-8859-1',



'txt_word_list'                     => 'List� Cuvinte',
'txt_word_list_description'         => 'Introduce�i un cuv�nt sau o fraz� pe linie.',

'txt_module_description'            => 'Filtrul de cuvinte �nlocuie�te cuvintele nedorite �i frazele cu un caracter pe care �l pute�i specifica mai �n jos. Activa�i Filtrul de cuvinte?',
'txt_module_name'                   => 'Filtru de cuvinte',

'txt_replacement_character'         => 'Caractere pentru �nlocuire',

);








?>
