<?php

/**
 * GentleSource
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language or have corrected typos, we would
 * appreciate it if you would send us the
 * translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset' => 'utf-8',



'txt_enable_module'                 => 'Mostra i Social Links',
'txt_enable_module_description'     => 'Attivando questa funzione verr&aacute; mostrato una lista composta da Bookmarking service come del.icio.us, digg eccâ¦, subito dopo il contenuto della pagina. Puoi modificare la lista agendo sul file template: link.tpl.html',

'txt_module_description'            => 'Mostra Social Link come del.icio.us, digg, ecc.',
'txt_module_name'                   => 'Social Links',

'txt_post_this_page'                => 'Condividi questa pagin in',

);








?>
