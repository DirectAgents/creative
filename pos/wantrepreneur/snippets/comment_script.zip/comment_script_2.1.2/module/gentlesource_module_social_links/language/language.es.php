<?php

/**
 * GentleSource
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset'                       => 'iso-8859-1',



'txt_enable_module'                 => 'Mostrar enlaces a marcadores',
'txt_enable_module_description'     => 'Si activas esta funci�n, se mostrar� una lista con enlaces a servicios de marcadores tales como men�ame, del.icio.us o digg en el p�e de  p�gina. Puedes modificar la lista en la plantilla link.tpl.html',

'txt_module_description'            => 'Muestra enlaces a marcadores tales como m�neame, del.icio.us, digg, etc...',
'txt_module_name'                   => 'Marcadores',

'txt_post_this_page'                => 'Enviar esta p�gina a',

);








?>
