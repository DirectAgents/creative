<?php

/** 
 * GentleSource Module Social Links
 * 
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 * 
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 * 
 */




$text = array(   

'txt_charset' => 'utf-8',



'txt_backend'                       => 'Backend',

'txt_enable_backend'                => 'Display Social Links',
'txt_enable_backend_description'    => 'By default the social services links will be displayed below each article. But you can also display the links below the article form in the admin backend. This way you can publish or bookmark an article without going to the frontend first.',

'txt_enable_module'                 => 'Afiºare Legãturi Sociale',
'txt_enable_module_description'     => 'Activarea acestei trãsãturi va afiºa o listã cu legãturi cãtre serviciile cu caracter social cum ar fi del.icio.us ori digg mai jos de conþinutul paginii. Puteþi edita lista în fiºierul link.tpl.html',

'txt_frontend'                      => 'Frontend',
'txt_frontend_backend'              => 'Frontend and backend',

'txt_module_description'            => 'Afiºare legãturi cãtre serviciile cu caracter social cum ar fi del.icio.us ori digg, etc.',
'txt_module_name'                   => 'Legãturi Sociale',

'txt_post_this_page'                => 'Trimite aceastã paginã la',

);








?>
