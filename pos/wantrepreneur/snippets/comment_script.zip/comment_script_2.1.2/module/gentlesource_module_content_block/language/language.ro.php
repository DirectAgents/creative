<?php

/** 
 * GentleSource Module Content Block
 * 
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 * 
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 * 
 */




$text = array(   

'txt_charset'                       => 'iso-8859-1',



'txt_error_content_block'           => 'Comentariul dvs-tr� a fost blocat.',

'txt_block_content'                 => 'Blocare Con�inut',
'txt_block_content_description'     => 'Introduce�i un cuv�nt sau o fraz� pe linie.',

'txt_moderate'                      => 'Moderare',
'txt_module_description'            => 'Modereaz� ori blocheaz� comentariile pe baza con�inutului postat.',
'txt_module_name'                   => 'Blocare Con�inut',

'txt_notice_moderation'             => 'Comentariul dvs-tr� va fi publicat odat� ce va fi aprobat de moderator.',

'txt_off'                           => 'Dezactivare',

'txt_reject'                        => 'Respingere',

);








?>
