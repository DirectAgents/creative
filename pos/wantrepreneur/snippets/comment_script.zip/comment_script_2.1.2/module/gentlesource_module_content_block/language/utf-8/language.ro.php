<?php

/** 
 * GentleSource Module Content Block
 * 
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 * 
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 * 
 */




$text = array(   

'txt_charset' => 'utf-8',



'txt_error_content_block'           => 'Comentariul dvs-trã a fost blocat.',

'txt_block_content'                 => 'Blocare Conþinut',
'txt_block_content_description'     => 'Introduceþi un cuvânt sau o frazã pe linie.',

'txt_moderate'                      => 'Moderare',
'txt_module_description'            => 'Modereazã ori blocheazã comentariile pe baza conþinutului postat.',
'txt_module_name'                   => 'Blocare Conþinut',

'txt_notice_moderation'             => 'Comentariul dvs-trã va fi publicat odatã ce va fi aprobat de moderator.',

'txt_off'                           => 'Dezactivare',

'txt_reject'                        => 'Respingere',

);








?>
