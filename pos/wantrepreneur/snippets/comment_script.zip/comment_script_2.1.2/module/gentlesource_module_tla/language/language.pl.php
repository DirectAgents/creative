<?php

/** 
 * GentleSource Guestbook Script - language.en.php
 * 
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 * 
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 * 
 */




$text = array(   

'txt_charset'                       => 'iso-8859-1',

'txt_ad_font_size'                  => 'Wielko�� czcionek dla reklam',
'txt_ads_per_row'                   => 'Ilo�� reklam w rz�dzie',

'txt_background_color'              => 'Kolor t�a',
'txt_border_color'                  => 'Kolor ramki',

'txt_enable_module'                 => 'W��cz reklamy tekstowe Text Link Ads',
'txt_enable_module_description'     => 'Wy�wietla reklamy z Text Link Ads.',

'txt_link_color'                    => 'Kolor linku',

'txt_module_description'            => 'Zarabiaj pieni�dze na wy�wietlaniu reklam. Wi�cej informacji na <a href="http://www.text-link-ads.com/?ref=37444" target="_blank">Text Link Ads</a>.',
'txt_module_name'                   => 'Text Link Ads',

'txt_tla_xml_key'                   => 'Klucz XML Text Link Ads ',
'txt_tla_xml_key_description'       => 'Klucz XML znajdziesz w swoim koncie na Text Link Ad. Zaloguj si� do konta, przejd� do "Publisher Program", kliknij "Install ad code", znajd� klucz XML poni�ej domeny Twojej strony.',

);








?>
