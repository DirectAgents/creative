<?php

/**
 * GentleSource
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language or have corrected typos, we would
 * appreciate it if you would send us the
 * translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset'                       => 'iso-8859-1',



'txt_ad_font_size'                  => 'Dimensione carattere per i tuoi banner',
'txt_ads_per_row'                   => 'Annunci di testo per riga',

'txt_background_color'              => 'Colore sfondo',
'txt_border_color'                  => 'Colore bordo',

'txt_enable_module'                 => 'Abilita collegamento annunci di testo',
'txt_enable_module_description'     => 'Mostra i link dagli annunci di testo.',

'txt_link_color'                    => 'Colore link',

'txt_module_description'            => 'Guadagna tramite il tuo sito e pubblica un semplice annuncio di testo pubblicitario o compra annunci per aumentare il traffico e il rank verso i motori di ricerca. Pi&uacute; info su <a href="http://www.text-link-ads.com/?ref=37444" target="_blank">Text Link Ads</a>.',
'txt_module_name'                   => 'Text Link Ads',

'txt_tla_xml_key'                   => 'XML Key Text Link Ads',
'txt_tla_xml_key_description'       => 'Puoi trovare la XML Key nel tuo account su Text Link Ad. Effettua il login sul tuo account, vai su \'Publiher Program\', clicca su \'Installa ad code\' e troverai il tuo XML Key dopo il dominio del tuo sito web.',

);








?>
