<?php

/**
 * GentleSource
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset'                       => 'iso-8859-1',



'txt_ad_font_size'                  => 'Textgr��e der Links',
'txt_ads_per_row'                   => 'Links pro Zeile',

'txt_background_color'              => 'Hintergrundfarbe',
'txt_border_color'                  => 'Randfarbe',

'txt_enable_module'                 => 'Text Link Ads einschalten',
'txt_enable_module_description'     => 'Links von Text Link Ads anzeigen.',

'txt_link_color'                    => 'Link-Farbe',

'txt_module_description'            => 'Verdienen Sie mit Ihrer Website Geld, indem Sie einfache Textlinks anzeigen. Oder kaufen Sie Textlinks, um die Besucherzahl Ihrer Website zu steigern. Weitere Informationen bei <a href="http://www.text-link-ads.com/?ref=37444" target="_blank">Text Link Ads</a>.',
'txt_module_name'                   => 'Text Link Ads',

'txt_tla_xml_key'                   => 'Text Link Ads XML-Schl�ssel',
'txt_tla_xml_key_description'       => 'Sie finden den XML-Schl�ssel in Ihrem Text-Link-Ad-Konto. Loggen Sie sich dort ein, gehen Sie zu "Publisher Program", klicken Sie auf "Install ad code". Der XML-Schl�ssel befindet sich unter der Domain Ihrer Website.',

);








?>
