<?php

/** 
 * GentleSource Guestbook Script - language.en.php
 * 
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 * 
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 * 
 */




$text = array(   

'txt_charset' => 'utf-8',

'txt_ad_font_size'                  => 'Wielko¶æ czcionek dla reklam',
'txt_ads_per_row'                   => 'Ilo¶æ reklam w rzêdzie',

'txt_background_color'              => 'Kolor t³a',
'txt_border_color'                  => 'Kolor ramki',

'txt_enable_module'                 => 'W³±cz reklamy tekstowe Text Link Ads',
'txt_enable_module_description'     => 'Wy¶wietla reklamy z Text Link Ads.',

'txt_link_color'                    => 'Kolor linku',

'txt_module_description'            => 'Zarabiaj pieni±dze na wy¶wietlaniu reklam. Wiêcej informacji na <a href="http://www.text-link-ads.com/?ref=37444" target="_blank">Text Link Ads</a>.',
'txt_module_name'                   => 'Text Link Ads',

'txt_tla_xml_key'                   => 'Klucz XML Text Link Ads ',
'txt_tla_xml_key_description'       => 'Klucz XML znajdziesz w swoim koncie na Text Link Ad. Zaloguj siê do konta, przejd¼ do "Publisher Program", kliknij "Install ad code", znajd¼ klucz XML poni¿ej domeny Twojej strony.',

);








?>
